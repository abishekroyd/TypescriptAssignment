var UserIdAutoincrement = 1001;
var CourseIdAutoincrement = 2001;
var User = /** @class */ (function () {
    function User(paramUsername, paramAge, paramMobileNumber) {
        this.userId = ("UI" + UserIdAutoincrement).toString();
        UserIdAutoincrement++;
        this.username = paramUsername;
        this.age = paramAge;
        this.mobilenumber = paramMobileNumber;
    }
    return User;
}());
var CourseInfo = /** @class */ (function () {
    function CourseInfo(paramCoursename, paramrequireddays) {
        this.courseId = ("CI" + CourseIdAutoincrement).toString();
        CourseIdAutoincrement++;
        this.coursename = paramCoursename;
        this.requireddays = paramrequireddays;
    }
    return CourseInfo;
}());
var UserInfo = /** @class */ (function () {
    function UserInfo(paramuserID, paramcoursename, paramrequireddays, paramusername) {
        this.userId = paramuserID;
        this.coursename = paramcoursename;
        this.requireddays = paramrequireddays;
        this.username = paramusername;
    }
    return UserInfo;
}());
var Userarraylist = new Array();
Userarraylist.push(new User("abishek", 24, 6380543827));
Userarraylist.push(new User("roy", 25, 9884216528));
var coursearraylist = new Array();
coursearraylist.push(new CourseInfo("html", 3));
coursearraylist.push(new CourseInfo("javascript", 5));
coursearraylist.push(new CourseInfo("CSS", 2));
var UserInformation = new Array();
function NewUser() {
    var homepage = document.getElementById("Homepage");
    var newuser = document.getElementById("Newuserpage");
    homepage.style.display = "none";
    newuser.style.display = "block";
}
function Register() {
    var newuser = document.getElementById("Newuserpage");
    var homepage = document.getElementById("Homepage");
    newuser.style.display = "none";
    var username = document.getElementById("username").value;
    var age = parseInt(document.getElementById("age").value);
    var mobilenumber = parseInt(document.getElementById("mobilenumber").value);
    Userarraylist.push(new User(username, age, mobilenumber));
    alert("User has been registered successfully");
    homepage.style.display = "block";
}
function Login() {
    var homepage = document.getElementById("Homepage");
    var login = document.getElementById("Loginpage");
    var availableusers = document.getElementById("displayuser");
    homepage.style.display = "none";
    login.style.display = "block";
    availableusers.innerHTML = "<h1>Available Users: </h1><br>";
    for (var i = 0; i < Userarraylist.length; i++) {
        availableusers.innerHTML += "UserID: ".concat(Userarraylist[i].userId, "  | Username: ").concat(Userarraylist[i].username, "<br>");
    }
}
function Courses() {
    var count = 0;
    var userid = document.getElementById("userid").value;
    var existingUserIdRegex = /^UI\d{4}$/;
    if (existingUserIdRegex.test(userid)) {
        for (var i = 0; i < Userarraylist.length; i++) {
            if ((Userarraylist[i].userId).toString() == (userid).toString()) {
                count++;
            }
        }
    }
    if (count == 0) {
        document.getElementById("invalid").innerHTML = "Invalid Input";
    }
    else if (count != 0) {
        var login = document.getElementById("Loginpage");
        var courses = document.getElementById("Courses");
        login.style.display = "none";
        courses.style.display = "block";
    }
}
function Availablecourse() {
    var courses = document.getElementById("Courses");
    var availablecourse = document.getElementById("AvailableCourses");
    courses.style.display = "none";
    availablecourse.style.display = "block";
}
function EnrollCourse() {
    var choice = document.getElementById("select");
    var choicevalue = choice[choice.selectedIndex].innerHTML;
    var count = 0;
    alert("The course has been enrolled successfully");
    var htmldays = 3;
    var cssdays = 2;
    var javascriptdays = 5;
    var days = 0;
    for (var i = 0; i < coursearraylist.length; i++) {
        if (coursearraylist[i].coursename == choicevalue) {
            count++;
        }
    }
    if (choice[choice.selectedIndex].innerHTML === "html") {
        days = htmldays;
    }
    else if (choice[choice.selectedIndex].innerHTML === "CSS") {
        days = cssdays;
    }
    else if (choice[choice.selectedIndex].innerHTML === "javascript") {
        days = javascriptdays;
    }
    var userName;
    var userid = document.getElementById("userid").value;
    for (var i = 0; i < Userarraylist.length; i++) {
        if ((Userarraylist[i].userId).toString() === (userid).toString()) {
            userName = Userarraylist[i].username;
        }
    }
    if (count != 0) {
        UserInformation.push(new UserInfo(userid, choicevalue, days, userName));
    }
    var homepage = document.getElementById("Homepage");
    var availablecourse = document.getElementById("AvailableCourses");
    availablecourse.style.display = "none";
    homepage.style.display = "block";
}
function EnrolledCourses() {
    var course = document.getElementById("Courses");
    var enrolledcourses = document.getElementById("EnrolledCourses");
    course.style.display = "none";
    var userid = document.getElementById("userid").value;
    var count = 0;
    var showhistory = document.getElementById("showhistory");
    for (var i = 0; i < UserInformation.length; i++) {
        if ((UserInformation[i].userId).toString() === userid) {
            count++;
        }
    }
    if (count == 0) {
        showhistory.innerHTML = "you have not enrolled in any courses yet hence click on available courses";
        enrolledcourses.style.display = "block";
    }
    else if (count != 0) {
        for (var i = 0; i < UserInformation.length; i++) {
            if ((UserInformation[i].userId).toString() === userid) {
                showhistory.innerHTML += "UserID: ".concat(UserInformation[i].userId, " |  UserName: ").concat(UserInformation[i].username, " | CourseEnrolled: ").concat(UserInformation[i].coursename, " | NumberofDays: ").concat(UserInformation[i].requireddays);
                enrolledcourses.style.display = "block";
            }
        }
    }
}
function home() {
    var enrolledcourses = document.getElementById("EnrolledCourses");
    var homepage = document.getElementById("Homepage");
    enrolledcourses.style.display = "none";
    homepage.style.display = "block";
}
