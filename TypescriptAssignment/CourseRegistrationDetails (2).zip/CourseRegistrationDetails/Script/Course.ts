let UserIdAutoincrement=1001;
let CourseIdAutoincrement=2001;





class User{
    userId:string;
    username:string;
    age:number;
    mobilenumber:number;
    constructor(paramUsername:string,paramAge:number,paramMobileNumber:number)
    {
        this.userId=("UI"+UserIdAutoincrement).toString();
        UserIdAutoincrement++;
        this.username=paramUsername;
        this.age=paramAge;
        this.mobilenumber=paramMobileNumber;

    }
}

class CourseInfo{
    courseId:string;
    coursename:string;
    requireddays:number;
    
    constructor(paramCoursename:string,paramrequireddays:number)
    {
        this.courseId=("CI"+CourseIdAutoincrement).toString();
        CourseIdAutoincrement++;
        this.coursename=paramCoursename;
        this.requireddays=paramrequireddays;
        
    }

}
class UserInfo{
    userId:string;
    coursename:string;
    requireddays:number;
    username:string;
    constructor(paramuserID:string,paramcoursename:string,paramrequireddays:number,paramusername:string)
    {
        this.userId=paramuserID;
        this.coursename=paramcoursename;
        this.requireddays=paramrequireddays;
        this.username=paramusername
    }
}

let Userarraylist: Array<User>=new Array<User>();
Userarraylist.push(new User("abishek",24,6380543827));
Userarraylist.push(new User("roy",25,9884216528));

let coursearraylist: Array<CourseInfo>=new Array<CourseInfo>();
coursearraylist.push(new CourseInfo("html",3));
coursearraylist.push(new CourseInfo("javascript",5));
coursearraylist.push(new CourseInfo("CSS",2));

let UserInformation:Array<UserInfo>=new Array<UserInfo>();

function NewUser()
{
    let homepage=document.getElementById("Homepage") as HTMLDivElement;
    let newuser=document.getElementById("Newuserpage") as HTMLDivElement;

    homepage.style.display="none";
    newuser.style.display="block";
}
function Register()
{
    let newuser=document.getElementById("Newuserpage") as HTMLDivElement;
    let homepage=document.getElementById("Homepage") as HTMLDivElement;
    newuser.style.display="none";
    let username=(document.getElementById("username") as HTMLInputElement).value;
    let age=parseInt((document.getElementById("age") as HTMLInputElement).value);
    let mobilenumber=parseInt((document.getElementById("mobilenumber") as HTMLInputElement).value);
    Userarraylist.push(new User(username,age,mobilenumber));
    alert("User has been registered successfully");
    homepage.style.display="block";
    
}
function Login()
{
    let homepage=document.getElementById("Homepage") as HTMLDivElement;
    let login=document.getElementById("Loginpage") as HTMLDivElement;
    let availableusers=document.getElementById("displayuser");
    homepage.style.display="none";
    login.style.display="block";
    availableusers.innerHTML=`<h1>Available Users: </h1><br>`;
    for(let i=0;i<Userarraylist.length;i++)
    {
        availableusers.innerHTML+=`UserID: ${Userarraylist[i].userId}  | Username: ${Userarraylist[i].username}<br>`;
    }

}
function Courses()
{
    let count=0;
    let userid=(document.getElementById("userid") as HTMLInputElement).value;
    
    let existingUserIdRegex = /^UI\d{4}$/;

    if (existingUserIdRegex.test(userid)) {
    for(let i=0;i<Userarraylist.length;i++)
    {
        if((Userarraylist[i].userId).toString()==(userid).toString())
        {
            count++;
        }
    }
}
    if(count==0)
    {
        document.getElementById("invalid").innerHTML="Invalid Input";
    }
    else if(count!=0) {
       
        let login=document.getElementById("Loginpage") as HTMLDivElement;
    let courses=document.getElementById("Courses") as HTMLDivElement;
    login.style.display="none";
    courses.style.display="block";
        
    }
}
function Availablecourse()
{
    let courses=document.getElementById("Courses") as HTMLDivElement;
    let availablecourse=document.getElementById("AvailableCourses") as HTMLDivElement;
    
    courses.style.display="none";
    availablecourse.style.display="block";
   
   

   
}

function EnrollCourse()
{
    let choice=(document.getElementById("select") as HTMLSelectElement);
    let choicevalue=choice[choice.selectedIndex].innerHTML;
    let count=0;
    alert("The course has been enrolled successfully");
    let htmldays=3;
    let cssdays=2;
    let javascriptdays=5;
    let days=0;
  
    for(let i=0;i<coursearraylist.length;i++)
    {
        if(coursearraylist[i].coursename==choicevalue)
        {
            count++;
        }
    }
    if(choice[choice.selectedIndex].innerHTML==="html")
    {
        days=htmldays;
    }
    else if(choice[choice.selectedIndex].innerHTML==="CSS")
    {
        days=cssdays;
    }
    else if(choice[choice.selectedIndex].innerHTML==="javascript")
    {
        days=javascriptdays;
    }
    let userName;
    let userid=(document.getElementById("userid") as HTMLInputElement).value;
    for(let i=0;i<Userarraylist.length;i++)
    {
        if((Userarraylist[i].userId).toString()===(userid).toString())
        {
            userName=Userarraylist[i].username;
        }
    }
    if(count!=0)
    {
        UserInformation.push(new UserInfo(userid,choicevalue,days,userName));
    }
    
    let homepage=document.getElementById("Homepage") as HTMLDivElement;
    let availablecourse=document.getElementById("AvailableCourses") as HTMLDivElement;
    availablecourse.style.display="none";
    homepage.style.display="block";
    
}
function EnrolledCourses()
{
    let course=document.getElementById("Courses") as HTMLDivElement;
    let enrolledcourses=document.getElementById("EnrolledCourses") as HTMLDivElement;
    course.style.display="none";
  
    let userid=(document.getElementById("userid") as HTMLInputElement).value;
    let count=0;
    let showhistory= document.getElementById("showhistory");

    for(let i=0;i<UserInformation.length;i++)
    {
        if((UserInformation[i].userId).toString()===userid)
        {
            count++;
        }
    }
    if(count==0)
    {
        
        
        showhistory.innerHTML="you have not enrolled in any courses yet hence click on available courses";
        enrolledcourses.style.display="block";
    }
    else if(count!=0)
    {
        for(let i=0;i<UserInformation.length;i++)
    {
        if((UserInformation[i].userId).toString()===userid)
        {
           showhistory.innerHTML+= `UserID: ${UserInformation[i].userId} |  UserName: ${UserInformation[i].username} | CourseEnrolled: ${UserInformation[i].coursename} | NumberofDays: ${UserInformation[i].requireddays}`
           enrolledcourses.style.display="block";
        }
    }
        
    }

}
function home()
{
    let enrolledcourses=document.getElementById("EnrolledCourses") as HTMLDivElement;
    let homepage=document.getElementById("Homepage") as HTMLDivElement;
    enrolledcourses.style.display="none";
    homepage.style.display="block";
}

    




